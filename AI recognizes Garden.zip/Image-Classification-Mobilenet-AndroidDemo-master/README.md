We have to preprocess the Image before giving it to the model to predict but it seems really challenging task to convert this image into required format.
conversion of Bitmap to ByteBuffer is difficult task in java so i converted my image into TensorBuffer.

Look at the source code to understand it better.

Thank You.
